CKEDITOR.editorConfig = function(config) {
    config.toolbarGroups = [
		// { name: 'document',	   groups: [ 'mode', 'document', 'doctools' ] },
		{ name: 'clipboard',   groups: [ 'clipboard', 'undo' ] },
		{ name: 'editing',     groups: [ 'find', 'selection'] },
		{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
        // { name: 'paragraph', groups: [ 'indent'] },		
	];

    // config.toolbar = 'MyToolbar';
    // config.toolbar_MyToolbar = [
    //         [ 'Bold','Underline','Italic','Strikethrough','Superscript','Indent' ]
    //          ];
    // config.language = 'es';
	// config.uiColor = '#F7B42C';
	config.extraPlugins = 'autogrow';
    config.extraPlugins = 'codesnippet';
    config.autoGrow_onStartup = true;
    config.autoGrow_minHeight = 100;
    config.autoGrow_maxHeight = 300;
	config.toolbarCanCollapse = true;
 };