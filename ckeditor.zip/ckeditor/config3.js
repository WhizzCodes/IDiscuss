CKEDITOR.editorConfig = function(config) {
    config.toolbar = [] ;
    config.readOnly = true;
    // config.height = 54;
    config.extraPlugins = 'autogrow';
    config.autoGrow_onStartup = true;
    config.autoGrow_minHeight = 54;
    config.autoGrow_maxHeight = 420;
    config.uiColor = '#66AB16';
    // CKEDITOR.addCss(".cke_editable{background-color: #F5F5F5}");
    // config.language = 'es';
	// config.uiColor = '#F7B42C';
	// config.height = 800;
	// config.toolbarCanCollapse = true;
 };
 //  CKEDITOR.config. extraPlugins = 'blockquote';
//  CKEDITOR.addCss(".cke_editable{background-color: gray}");
//  CKEDITOR.config.uiColor = '#fff';
{/* <p class="fw-normal">' . $desc . '</p>

<p>' . $content . '</p>

<p class="fs-6 fw-light" style="color: #999999;">' . $row2['user_name'] . ' at ' . $comment_time . '</p>	  */}